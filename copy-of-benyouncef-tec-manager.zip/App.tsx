
import React, { useState, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Wrench, 
  Package, 
  Users, 
  CreditCard, 
  Calendar, 
  Menu, 
  X,
  Bell,
  Search,
  Plus
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import Interventions from './components/Interventions';
import Inventory from './components/Inventory';
import Clients from './components/Clients';
import Finance from './components/Finance';
import Planning from './components/Planning';

type Tab = 'dashboard' | 'interventions' | 'inventory' | 'clients' | 'finance' | 'planning';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const menuItems = [
    { id: 'dashboard', label: 'Tableau de Bord', icon: LayoutDashboard },
    { id: 'interventions', label: 'Interventions', icon: Wrench },
    { id: 'planning', label: 'Planning', icon: Calendar },
    { id: 'inventory', label: 'Stocks & Pièces', icon: Package },
    { id: 'clients', label: 'Base Clients', icon: Users },
    { id: 'finance', label: 'Facturation & Devis', icon: CreditCard },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'interventions': return <Interventions />;
      case 'inventory': return <Inventory />;
      case 'clients': return <Clients />;
      case 'finance': return <Finance />;
      case 'planning': return <Planning />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside 
        className={`${
          isSidebarOpen ? 'w-64' : 'w-20'
        } bg-slate-900 text-white transition-all duration-300 flex flex-col z-50`}
      >
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Wrench className="w-6 h-6 text-white" />
          </div>
          {isSidebarOpen && <span className="font-bold text-xl tracking-tight">BenTEC</span>}
        </div>

        <nav className="flex-1 mt-6 px-3 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as Tab)}
              className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {isSidebarOpen && <span className="font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="flex items-center gap-3 text-slate-400 hover:text-white w-full p-2"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            {isSidebarOpen && <span>Réduire</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-4 bg-slate-100 px-4 py-2 rounded-full w-96 border border-slate-200">
            <Search className="w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Rechercher client, machine, pièce..." 
              className="bg-transparent border-none outline-none text-sm w-full"
            />
          </div>
          
          <div className="flex items-center gap-6">
            <div className="relative cursor-pointer group">
              <Bell className="w-5 h-5 text-slate-600 group-hover:text-blue-600 transition-colors" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full border-2 border-white font-bold">3</span>
            </div>
            <div className="flex items-center gap-3 border-l pl-6 border-slate-200">
              <div className="text-right">
                <p className="text-sm font-semibold text-slate-900 leading-none">Admin Benyouncef</p>
                <p className="text-xs text-slate-500 mt-1">Administrateur</p>
              </div>
              <img 
                src="https://picsum.photos/seed/admin/100/100" 
                alt="Profile" 
                className="w-10 h-10 rounded-full border-2 border-slate-100 shadow-sm"
              />
            </div>
          </div>
        </header>

        {/* Dynamic Content */}
        <div className="flex-1 overflow-y-auto bg-slate-50 p-8">
          <div className="max-w-7xl mx-auto animate-fadeIn">
            {renderContent()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
