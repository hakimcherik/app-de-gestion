
import React from 'react';
import { 
  FileText, 
  Download, 
  MoreHorizontal,
  CheckCircle2,
  Clock,
  ExternalLink
} from 'lucide-react';
import CopyButton from './CopyButton';

const mockInvoices = [
  { id: 'FAC-24-001', client: 'Sonelgaz', date: '10/05/2024', amount: 3500.00, status: 'Payée' },
  { id: 'FAC-24-002', client: 'Cosider', date: '12/05/2024', amount: 1250.00, status: 'En attente' },
  { id: 'FAC-24-003', client: 'Seaal', date: '15/05/2024', amount: 480.00, status: 'Payée' },
  { id: 'FAC-24-004', client: 'Anas', date: '16/05/2024', amount: 2100.00, status: 'En attente' },
];

const Finance: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Facturation & Devis</h1>
          <p className="text-slate-500 text-sm">Gestion des documents financiers et règlements.</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-700 transition-all">
          <FileText className="w-5 h-5" />
          Nouveau Devis
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm border-l-4 border-l-emerald-500">
          <p className="text-slate-500 text-xs font-bold uppercase mb-1">Total Encaissé</p>
          <p className="text-2xl font-bold text-slate-900">12,450.00 €</p>
          <p className="text-xs text-emerald-600 mt-2 flex items-center gap-1 font-semibold">
            <CheckCircle2 className="w-3 h-3" /> Ce mois-ci
          </p>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm border-l-4 border-l-amber-500">
          <p className="text-slate-500 text-xs font-bold uppercase mb-1">Encours Client</p>
          <p className="text-2xl font-bold text-slate-900">3,350.00 €</p>
          <p className="text-xs text-amber-600 mt-2 flex items-center gap-1 font-semibold">
            <Clock className="w-3 h-3" /> 4 factures en attente
          </p>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm border-l-4 border-l-blue-500">
          <p className="text-slate-500 text-xs font-bold uppercase mb-1">Devis Ouverts</p>
          <p className="text-2xl font-bold text-slate-900">8</p>
          <p className="text-xs text-blue-600 mt-2 flex items-center gap-1 font-semibold">
            <ExternalLink className="w-3 h-3" /> Valeur : 15,200 €
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h3 className="font-bold text-slate-900">Factures Récentes</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">N° Facture</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Client</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Date</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Montant</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Statut</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-700">{inv.id}</span>
                      <CopyButton text={inv.id} />
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-semibold text-slate-900">{inv.client}</td>
                  <td className="px-6 py-4 text-sm text-slate-500">{inv.date}</td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-900">{inv.amount.toLocaleString()} €</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                      inv.status === 'Payée' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button title="Télécharger PDF" className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-blue-50">
                        <Download className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-slate-900 rounded-lg hover:bg-slate-100">
                        <MoreHorizontal className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Finance;
