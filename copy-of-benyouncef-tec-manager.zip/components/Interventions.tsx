
import React, { useState } from 'react';
import { 
  Plus, 
  Filter, 
  MoreVertical, 
  Clock, 
  CheckCircle, 
  Settings,
  AlertCircle,
  Package,
  CalendarDays,
  X,
  User,
  Tool,
  MapPin,
  Eye
} from 'lucide-react';
import { InterventionStatus, MachineType } from '../types';
import CopyButton from './CopyButton';

const mockInterventions = [
  { 
    id: 'INT-2024-001', 
    client: 'Cosider Canalisations', 
    machine: 'Bout à bout 630mm', 
    status: InterventionStatus.PLANNED, 
    date: '2024-05-15', 
    technician: 'Rachid M.',
    description: 'Maintenance préventive trimestrielle. Vérification des systèmes hydrauliques et étalonnage du capteur de pression.',
    location: 'Chantier El Harrach, Alger',
    contact: 'M. Ahmed (+213 550 12 34 56)'
  },
  { 
    id: 'INT-2024-002', 
    client: 'Sonatrach', 
    machine: 'Électrofusion MSA 4.0', 
    status: InterventionStatus.COMPLETED, 
    date: '2024-05-12', 
    technician: 'Karim L.',
    description: 'Remplacement de la carte mère défectueuse suite à une surtension. Test de soudure validé.',
    location: 'Base Vie Hassi Messaoud',
    contact: 'Service Maintenance Nord'
  },
  { 
    id: 'INT-2024-003', 
    client: 'GIPEC', 
    machine: 'Écrase-tubes 160mm', 
    status: InterventionStatus.DIAGNOSTIC, 
    date: '2024-05-18', 
    technician: 'Hamid T.',
    description: 'Fuite hydraulique signalée au niveau du vérin principal. Diagnostic en cours pour identification des joints à remplacer.',
    location: 'Usine Boumerdes',
    contact: 'Direction Technique'
  },
  { 
    id: 'INT-2024-004', 
    client: 'SARL GazElec', 
    machine: 'Générateur Poly', 
    status: InterventionStatus.PARTS_ORDERED, 
    date: '2024-05-20', 
    technician: 'Karim L.',
    description: 'Bobinage alternateur à refaire. Pièces en attente de livraison fournisseur.',
    location: 'Dépôt Blida',
    contact: 'Dépôt Logistique'
  },
];

const StatusBadge = ({ status }: { status: InterventionStatus }) => {
  const styles: any = {
    [InterventionStatus.PENDING]: 'bg-slate-100 text-slate-700',
    [InterventionStatus.DIAGNOSTIC]: 'bg-blue-100 text-blue-700',
    [InterventionStatus.PARTS_ORDERED]: 'bg-amber-100 text-amber-700',
    [InterventionStatus.PLANNED]: 'bg-indigo-100 text-indigo-700',
    [InterventionStatus.COMPLETED]: 'bg-emerald-100 text-emerald-700',
    [InterventionStatus.INVOICED]: 'bg-purple-100 text-purple-700',
  };

  const icons: any = {
    [InterventionStatus.PENDING]: Clock,
    [InterventionStatus.DIAGNOSTIC]: Settings,
    [InterventionStatus.PARTS_ORDERED]: Package,
    [InterventionStatus.PLANNED]: CalendarDays,
    [InterventionStatus.COMPLETED]: CheckCircle,
    [InterventionStatus.INVOICED]: CheckCircle,
  };

  const Icon = icons[status];

  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${styles[status]}`}>
      <Icon className="w-3.5 h-3.5" />
      {status}
    </span>
  );
};

const Interventions: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIntervention, setSelectedIntervention] = useState<typeof mockInterventions[0] | null>(null);

  const closeModal = () => setSelectedIntervention(null);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestion des Interventions</h1>
          <p className="text-slate-500 text-sm">Suivi et planification des maintenances machines.</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all">
          <Plus className="w-5 h-5" />
          Nouvelle Intervention
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-4 bg-slate-50/50">
          <div className="relative flex-1">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Filtrer par client, machine ou ID..." 
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <select className="bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none">
            <option>Tous les statuts</option>
            {Object.values(InterventionStatus).map(s => <option key={s}>{s}</option>)}
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/50">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">ID / Date</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Client</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Machine</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Statut</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Technicien</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockInterventions.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-blue-600 text-sm">{item.id}</span>
                        <CopyButton text={item.id} />
                      </div>
                      <span className="text-xs text-slate-400">{item.date}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-900">{item.client}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{item.machine}</td>
                  <td className="px-6 py-4">
                    <StatusBadge status={item.status} />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 bg-slate-200 rounded-full flex items-center justify-center text-[10px] font-bold text-slate-600">
                        {item.technician.split(' ').map(n => n[0]).join('')}
                      </div>
                      <span className="text-sm text-slate-600">{item.technician}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => setSelectedIntervention(item)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Voir détails
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-all">
                        <MoreVertical className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedIntervention && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in duration-300">
            {/* Modal Header */}
            <div className="px-8 py-6 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold text-blue-600 uppercase tracking-widest bg-blue-50 px-2 py-0.5 rounded">Intervention</span>
                  <h2 className="text-xl font-bold text-slate-900">{selectedIntervention.id}</h2>
                </div>
                <p className="text-sm text-slate-500">Planifiée pour le {selectedIntervention.date}</p>
              </div>
              <button 
                onClick={closeModal}
                className="p-2 hover:bg-slate-200 rounded-full text-slate-400 hover:text-slate-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="px-8 py-8 space-y-8 max-h-[70vh] overflow-y-auto">
              {/* Summary Grid */}
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Client</label>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{selectedIntervention.client}</p>
                      <p className="text-xs text-slate-500">{selectedIntervention.contact}</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Machine</label>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                      <Settings className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{selectedIntervention.machine}</p>
                      <p className="text-xs text-slate-500">Maintenance Industrielle</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Lieu</label>
                  <div className="flex items-center gap-2 text-slate-600">
                    <MapPin className="w-4 h-4 text-red-500" />
                    <span className="text-sm">{selectedIntervention.location}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Technicien</label>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-[10px] font-bold">
                      {selectedIntervention.technician.charAt(0)}
                    </div>
                    <span className="text-sm font-semibold text-slate-700">{selectedIntervention.technician}</span>
                  </div>
                </div>
              </div>

              {/* Status Section */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <label className="text-sm font-bold text-slate-900">Statut Actuel :</label>
                  <StatusBadge status={selectedIntervention.status} />
                </div>
                <button className="text-xs font-bold text-blue-600 hover:underline">Modifier le statut</button>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Description des travaux / Diagnostic</label>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <p className="text-sm text-slate-700 leading-relaxed italic">
                    "{selectedIntervention.description}"
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 pt-4 border-t border-slate-100">
                <button className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200">
                  Modifier l'intervention
                </button>
                <button className="px-6 py-3 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-all">
                  Générer rapport PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Interventions;
