
import React from 'react';
import { 
  Plus, 
  Package, 
  AlertTriangle, 
  Search, 
  ChevronRight,
  ArrowRightLeft
} from 'lucide-react';
import CopyButton from './CopyButton';

const mockParts = [
  { id: 1, name: 'Carte Mère MSA 4.0', ref: 'ELC-9908', stock: 2, min: 5, price: 1250 },
  { id: 2, name: 'Lame de Découpe 315mm', ref: 'MEC-315', stock: 15, min: 10, price: 85 },
  { id: 3, name: 'Réducteur de Tension', ref: 'ACC-V12', stock: 4, min: 4, price: 210 },
  { id: 4, name: 'Kit Joint Hydraulique', ref: 'HYD-001', stock: 25, min: 15, price: 45 },
  { id: 5, name: 'Câble Alimentation IP67', ref: 'ELE-PWR', stock: 1, min: 3, price: 120 },
];

const Inventory: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Stocks & Pièces Détachées</h1>
          <p className="text-slate-500 text-sm">Gestion de l'inventaire et réapprovisionnement.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 bg-slate-100 text-slate-700 px-5 py-2.5 rounded-xl font-semibold hover:bg-slate-200 transition-all">
            <ArrowRightLeft className="w-4 h-4" />
            Mouvements
          </button>
          <button className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all">
            <Plus className="w-5 h-5" />
            Ajouter une Pièce
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Total Références</p>
            <p className="text-2xl font-bold text-slate-900">248</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Stock Critique</p>
            <p className="text-2xl font-bold text-slate-900">12</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <Search className="w-6 h-6" />
          </div>
          <div>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Valeur Totale</p>
            <p className="text-2xl font-bold text-slate-900">84,500 €</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900">Liste des Stocks</h3>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-50 text-red-600 border border-red-100">
              Alertes Uniquement
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Référence</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Désignation</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Stock Actuel</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Seuil Min.</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Prix Unitaire</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockParts.map((part) => (
                <tr key={part.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm text-slate-600">{part.ref}</span>
                      <CopyButton text={part.ref} />
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-semibold text-slate-900">{part.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-md font-bold text-sm ${
                      part.stock <= part.min / 2 ? 'bg-red-100 text-red-600' :
                      part.stock <= part.min ? 'bg-amber-100 text-amber-600' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {part.stock} unités
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">{part.min}</td>
                  <td className="px-6 py-4 text-sm font-semibold text-slate-900">{part.price.toLocaleString()} €</td>
                  <td className="px-6 py-4">
                    <button className="text-blue-600 hover:text-blue-800 transition-colors p-1 rounded-lg hover:bg-blue-50">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
