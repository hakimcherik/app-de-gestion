
import React from 'react';
import { Users, Mail, Phone, MapPin, Search, ChevronRight, HardDrive } from 'lucide-react';
import CopyButton from './CopyButton';

const mockClients = [
  { id: 1, name: 'Cosider Canalisations', location: 'Alger', count: 12, phone: '021 00 11 22', mail: 'contact@cosider.dz' },
  { id: 2, name: 'SEAAL', location: 'Alger / Tipaza', count: 8, phone: '021 33 44 55', mail: 'maintenance@seaal.dz' },
  { id: 3, name: 'Sonatrach', location: 'Hassi Messaoud', count: 25, phone: '029 11 22 33', mail: 'tech@sonatrach.dz' },
  { id: 4, name: 'GIPEC', location: 'Boumerdes', count: 4, phone: '024 44 55 66', mail: 'gipec@groupe.dz' },
];

const Clients: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Base Clients & Équipements</h1>
          <p className="text-slate-500 text-sm">Répertoire des entreprises et suivi de leur parc machine.</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-700 transition-all">
          <Users className="w-5 h-5" />
          Nouveau Client
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockClients.map(client => (
          <div key={client.id} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all group cursor-pointer relative">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-all">
                  <Users className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-lg leading-tight">{client.name}</h3>
                  <div className="flex items-center gap-1 text-slate-400 text-xs mt-1">
                    <MapPin className="w-3 h-3" /> {client.location}
                  </div>
                </div>
              </div>
              <div className="bg-slate-50 px-3 py-2 rounded-xl border border-slate-100 text-center">
                <span className="block text-blue-600 font-bold text-lg">{client.count}</span>
                <span className="block text-[10px] uppercase font-bold text-slate-400">Machines</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="flex items-center justify-between gap-2 p-2 bg-slate-50 rounded-lg group/item transition-colors hover:bg-blue-50/50">
                <div className="flex items-center gap-2 text-sm text-slate-600 overflow-hidden">
                  <Mail className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span className="truncate">{client.mail}</span>
                </div>
                <CopyButton text={client.mail} className="flex-shrink-0 opacity-0 group-hover/item:opacity-100" />
              </div>
              <div className="flex items-center justify-between gap-2 p-2 bg-slate-50 rounded-lg group/item transition-colors hover:bg-blue-50/50">
                <div className="flex items-center gap-2 text-sm text-slate-600 overflow-hidden">
                  <Phone className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span>{client.phone}</span>
                </div>
                <CopyButton text={client.phone} className="flex-shrink-0 opacity-0 group-hover/item:opacity-100" />
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-blue-500" />
                <span className="text-xs font-semibold text-slate-500 italic">Dernière intervention : 02 Mai 2024</span>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-500 transition-all translate-x-0 group-hover:translate-x-1" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Clients;
