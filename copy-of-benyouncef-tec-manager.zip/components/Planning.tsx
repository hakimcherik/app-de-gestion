
import React from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  User,
  Calendar as CalendarIcon,
  MapPin
} from 'lucide-react';

const technicians = ['Karim L.', 'Rachid M.', 'Hamid T.', 'Sofiane B.'];
const days = ['Lun 13', 'Mar 14', 'Mer 15', 'Jeu 16', 'Ven 17', 'Sam 18'];

const Planning: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Planning des Techniciens</h1>
          <p className="text-slate-500 text-sm">Organisation des tournées et interventions sur site.</p>
        </div>
        <div className="flex items-center gap-4 bg-white p-2 rounded-xl border border-slate-200">
          <button className="p-1 hover:bg-slate-100 rounded-lg"><ChevronLeft className="w-5 h-5" /></button>
          <span className="font-bold text-slate-900 px-2 text-sm">Semaine 20 - Mai 2024</span>
          <button className="p-1 hover:bg-slate-100 rounded-lg"><ChevronRight className="w-5 h-5" /></button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="grid grid-cols-7 border-b border-slate-100 bg-slate-50">
          <div className="p-4 border-r border-slate-100 flex items-center justify-center font-bold text-slate-400 text-xs uppercase">Technicien</div>
          {days.map(day => (
            <div key={day} className="p-4 text-center border-r border-slate-100 font-bold text-slate-700 text-sm">
              {day}
            </div>
          ))}
        </div>

        <div className="divide-y divide-slate-100">
          {technicians.map(tech => (
            <div key={tech} className="grid grid-cols-7">
              <div className="p-4 border-r border-slate-100 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs">
                  {tech.charAt(0)}
                </div>
                <span className="text-sm font-semibold text-slate-700">{tech}</span>
              </div>
              
              {/* Mock Timeline Slots */}
              <div className="p-2 border-r border-slate-100">
                <div className="h-full bg-blue-50 border-l-4 border-blue-500 p-2 rounded-md">
                  <p className="text-[10px] font-bold text-blue-700 uppercase">08:30 - 12:00</p>
                  <p className="text-xs font-semibold text-slate-800 truncate">Cosider - Canalisations</p>
                  <div className="flex items-center gap-1 mt-1 text-[10px] text-slate-500">
                    <MapPin className="w-2 h-2" /> <span>Alger, El Harrach</span>
                  </div>
                </div>
              </div>

              <div className="p-2 border-r border-slate-100">
                 <div className="h-full flex items-center justify-center opacity-20">
                   <CalendarIcon className="w-4 h-4" />
                 </div>
              </div>

              <div className="p-2 border-r border-slate-100">
                <div className="h-full bg-emerald-50 border-l-4 border-emerald-500 p-2 rounded-md">
                  <p className="text-[10px] font-bold text-emerald-700 uppercase">10:00 - 16:30</p>
                  <p className="text-xs font-semibold text-slate-800 truncate">GIPEC - Maintenance</p>
                </div>
              </div>

              <div className="p-2 border-r border-slate-100 bg-slate-50/30"></div>
              <div className="p-2 border-r border-slate-100"></div>
              <div className="p-2 border-r border-slate-100 bg-slate-50/50"></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Planning;
