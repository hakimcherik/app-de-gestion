
import React from 'react';
import { 
  Users, 
  Wrench, 
  AlertTriangle, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  AreaChart,
  Area
} from 'recharts';

const dataActivity = [
  { name: 'Jan', count: 12 },
  { name: 'Fév', count: 18 },
  { name: 'Mar', count: 15 },
  { name: 'Avr', count: 22 },
  { name: 'Mai', count: 28 },
  { name: 'Juin', count: 24 },
];

const revenueData = [
  { name: 'Lun', value: 4000 },
  { name: 'Mar', value: 3000 },
  { name: 'Mer', value: 2000 },
  { name: 'Jeu', value: 2780 },
  { name: 'Ven', value: 1890 },
  { name: 'Sam', value: 2390 },
  { name: 'Dim', value: 3490 },
];

const StatCard = ({ title, value, icon: Icon, trend, trendValue, color }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full ${trend === 'up' ? 'text-green-600 bg-green-50' : 'text-red-600 bg-red-50'}`}>
        {trend === 'up' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
        {trendValue}
      </div>
    </div>
    <h3 className="text-slate-500 text-sm font-medium">{title}</h3>
    <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
  </div>
);

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Bonjour, Benyouncef</h1>
        <p className="text-slate-500">Aperçu général de l'activité de maintenance industrielle.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Interventions Actives" 
          value="24" 
          icon={Wrench} 
          trend="up" 
          trendValue="+12%" 
          color="bg-blue-600"
        />
        <StatCard 
          title="Nouveaux Clients" 
          value="156" 
          icon={Users} 
          trend="up" 
          trendValue="+5%" 
          color="bg-indigo-600"
        />
        <StatCard 
          title="Alertes Stock" 
          value="08" 
          icon={AlertTriangle} 
          trend="down" 
          trendValue="-2%" 
          color="bg-amber-500"
        />
        <StatCard 
          title="Chiffre d'Affaires" 
          value="45,280 €" 
          icon={TrendingUp} 
          trend="up" 
          trendValue="+18%" 
          color="bg-emerald-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-slate-900 text-lg">Évolution des Interventions</h3>
            <select className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-1 outline-none">
              <option>6 derniers mois</option>
              <option>12 derniers mois</option>
            </select>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dataActivity}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="count" stroke="#2563eb" strokeWidth={3} fillOpacity={1} fill="url(#colorCount)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="font-bold text-slate-900 text-lg mb-6">Dernières Activités</h3>
          <div className="space-y-6 flex-1">
            {[
              { id: 1, type: 'status', label: 'Intervention Terminée', user: 'Tech. Sid Ahmed', time: 'il y a 2h', icon: CheckCircle2, color: 'text-green-500' },
              { id: 2, type: 'alert', label: 'Stock Critique : Carte Mère', user: 'Entrepôt', time: 'il y a 5h', icon: AlertTriangle, color: 'text-amber-500' },
              { id: 3, type: 'client', label: 'Nouveau Client : SONELGAZ', user: 'Admin', time: 'il y a 8h', icon: Users, color: 'text-blue-500' },
              { id: 4, type: 'urgent', label: 'Réparation Urgente Demandée', user: 'Client Cosider', time: 'il y a 10h', icon: Clock, color: 'text-indigo-500' },
            ].map((activity) => (
              <div key={activity.id} className="flex gap-4">
                <div className={`p-2 rounded-lg bg-slate-50 ${activity.color}`}>
                  <activity.icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900">{activity.label}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-slate-500">{activity.user}</span>
                    <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                    <span className="text-xs text-slate-400">{activity.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="mt-6 w-full py-3 text-sm font-semibold text-blue-600 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors">
            Voir tout l'historique
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
