
export enum MachineType {
  BUTT_WELDING = 'Bout à bout',
  ELECTROFUSION = 'Électrofusion',
  PIPE_SQUEEZER = 'Écrase-tubes',
  ACCESSORIES = 'Accessoires'
}

export enum InterventionStatus {
  PENDING = 'En attente',
  DIAGNOSTIC = 'Diagnostic',
  PARTS_ORDERED = 'Pièces commandées',
  PLANNED = 'Planifiée',
  COMPLETED = 'Terminée',
  INVOICED = 'Facturée'
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface Machine {
  id: string;
  clientId: string;
  type: MachineType;
  model: string;
  serialNumber: string;
  lastMaintenance?: string;
}

export interface SparePart {
  id: string;
  name: string;
  reference: string;
  quantity: number;
  minThreshold: number;
  price: number;
}

export interface Intervention {
  id: string;
  clientId: string;
  machineId: string;
  description: string;
  status: InterventionStatus;
  createdAt: string;
  plannedDate?: string;
  technicianId?: string;
  cost?: number;
  partsUsed: { partId: string; quantity: number }[];
}

export interface Invoice {
  id: string;
  interventionId: string;
  amount: number;
  date: string;
  status: 'Payée' | 'Impayée';
}
